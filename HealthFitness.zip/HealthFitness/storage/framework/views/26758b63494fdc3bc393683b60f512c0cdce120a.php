
<?php $__env->startSection('content'); ?>
	<div class="col-md-10 offset-1">
		 
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">Category</h3>
			</div>
			<form action="<?php echo e(route('category.store')); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
				<div class="card-body">
				
				
				 
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Category Name</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="category_name" class="form-control">
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Category Image</label>
						</div>
						<div class="col-md-8">
							<input type="file" name="category_image" class="form-control">
						</div>
	
					</div>	
					<input type="submit" value="ADD" class="btn btn-dark">
				</div>
			</form>	
			
		</div>	
			
		

		</div>
		<div class="col-md-12 mt-5">
			<h3>Car list</h3>
			<table class="table table-active">
				<thead>
					<th>NO.</th>
					<th>Category Name</th>
					<th>Image</th>
				 
					<th>Action</th>
				</thead>
				<?php $i = 1 ?>
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tbody>
					
						<td><?php echo e($i++); ?></td>
						<td><?php echo e($category->category_name); ?></td>
						<td><img src="<?php echo e($category->category_image); ?>" width="300" height="300"></td>
					 
						 
						<td> 
							<a href="<?php echo e(route('category.edit',$category->id)); ?>" class="btn btn-primary float-left mr-3">Edit </a>
							<form action="<?php echo e(route('category.destroy',$category->id)); ?>" method="post">
			                  <?php echo method_field('Delete'); ?>
			                  <?php echo csrf_field(); ?>
			                  <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                			</form>

                		</td>		
				
				</tbody>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HealthFitness\resources\views/category/index.blade.php ENDPATH**/ ?>