<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/head/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('category.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Category</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('food.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Food</span></a>
      </li>
      
      
      
    </ul>
<?php /**PATH C:\xampp\htdocs\HealthFitness\resources\views/sidebar.blade.php ENDPATH**/ ?>