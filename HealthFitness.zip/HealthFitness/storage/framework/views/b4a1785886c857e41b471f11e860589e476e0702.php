<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/head/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href=" ">
          <i class="fas fa-fw fa-table"></i>
          <span>Simple</span></a>
      </li>
      
      
      
    </ul>
<?php /**PATH C:\xampp\htdocs\FoodReview\resources\views/sidebar.blade.php ENDPATH**/ ?>