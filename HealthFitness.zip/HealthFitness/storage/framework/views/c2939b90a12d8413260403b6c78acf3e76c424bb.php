
<?php $__env->startSection('content'); ?>
	<div class="col-md-10 offset-1">
		 
		<div class="card">
			<div class="card-header">
				<h3 class="card-title">food</h3>
			</div>
			<form action="<?php echo e(route('food.update',$food->id)); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PUT'); ?>
				<div class="card-body">
				
				
				 
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>food Name</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="food_name" class="form-control" value="<?php echo e($food->food_name); ?>">
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Calories</label>
						</div>
						<div class="col-md-8">
							<input type="text" name="calories" class="form-control" value="<?php echo e($food->calories); ?>">
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>Category</label>
						</div>
						<div class="col-md-8">
							<select name="category" class="form-control">
								<option selected disabled>Select Category</option>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->id); ?>"
										<?php if($category->id == $food->category_id): ?>
										<?php echo e('selected'); ?>

										<?php endif; ?>
										><?php echo e($category->category_name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
	
					</div>
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>New Image</label>
						</div>
						<div class="col-md-8">
							<input type="file" name="food_image" class="form-control">
						</div>
	
					</div>	
					<div class="row form-group">
						<div class="col-md-3 ">
							<label>old Image</label>
						</div>
						<div class="col-md-8">
							<img src="<?php echo e($food->food_image); ?>" width="150" height="150">
						</div>
						<input type="hidden" name="old_image" value="<?php echo e($food->food_image); ?>">
	
					</div>		
					<input type="submit" value="ADD" class="btn btn-dark">
				</div>
			</form>	
			
		</div>	
			
		

		</div>

</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HealthFitness\resources\views/food/edit.blade.php ENDPATH**/ ?>