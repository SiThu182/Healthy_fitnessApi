<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Food;
use App\Http\Resources\FoodResource;
class FoodController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $foods = Food::all();
        $foods = FoodResource::collection($foods);
        return response()->json([
            'foods' => $foods
        ],200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
          $request->validate([
            'f_name'    => 'required|min:3|max:30',
            'calories'  => 'required|min:1|max:30',
            'category'  => 'required',
            'food_image'=> 'required' 
        ]);



        if($request->hasfile('food_image')){
            $photo=$request->file('food_image');
            $name=time().'.'.$photo->getClientOriginalExtension();
            $photo->move(public_path().'/storage/photos/',$name);
            $image='/storage/photos/'.$name;
             
         }

         

            Food::create([
            'f_name'        => request('food_name'),
            'calories'      => request('calories'),
            'category_id'   => request('category'),
            'food_image'    => $image
        ]);

            return response()->json([
                'message' => 'Successfully food Insert!'
            ],200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $food = Food::find($id);
        $food = FoodResource::make($food);
        return response()->json([
            'food' => $food
        ],200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $request->validate([
            'food_name'    => 'required|min:3|max:30',
            'calories'  => 'required|min:1|max:30',
            'category'  => 'required'
        ]);



        if($request->hasfile('food_image')){
            $photo=$request->file('food_image');
            $name=time().'.'.$photo->getClientOriginalExtension();
            $photo->move(public_path().'/storage/photos/',$name);
            $image='/storage/photos/'.$name;
             
         }else{
            $image = $request->old_image;
         }

            $food = Food::find($id);
            $food->food_name = $request->food_name;
            $food->calories = $request->calories;
            $food->category_id = $request->category;
            $food->food_image = $request->food_image;
            $food->save();

            return response()->json([
                'message' => "Successfully Food Update!"
            ],200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $food =Food::find($id);
        $food->delete();
        return response()->json([
            'message' => "Successfully food Delete!"
        ],200);
    }
}
